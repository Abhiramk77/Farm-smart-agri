import { mockBackend } from './mockBackend';

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = 'ApiError';
  }
}

// Helper to simulate network delay
const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = localStorage.getItem('auth_token');
  
  // -- INTERCEPT FOR MOCK BACKEND --
  // We use the mock backend since the real server is not available yet.
  await delay(800); // Simulate network latency

  if (endpoint.startsWith('/contracts/marketplace') && options.method === 'GET') {
    return mockBackend.getContracts('marketplace') as unknown as T;
  }
  
  if (endpoint.match(/^\/contracts\?status=(.*)$/) && options.method === 'GET') {
    const status = endpoint.split('=')[1];
    return mockBackend.getContracts(status) as unknown as T;
  }

  if (endpoint === '/contracts' && options.method === 'GET') {
    return mockBackend.getContracts() as unknown as T;
  }

  if (endpoint.startsWith('/contracts/') && options.method === 'GET') {
    const id = endpoint.split('/').pop()!;
    const contract = mockBackend.getContract(id);
    if (!contract) throw new ApiError(404, 'Contract not found');
    return contract as unknown as T;
  }

  if (endpoint === '/contracts' && options.method === 'POST') {
    const body = JSON.parse(options.body as string);
    return mockBackend.createContract(body) as unknown as T;
  }

  if (endpoint.match(/^\/contracts\/(.*)\/accept$/) && options.method === 'POST') {
    const id = endpoint.split('/')[2];
    return mockBackend.acceptContract(id) as unknown as T;
  }

  if (endpoint.match(/^\/contracts\/(.*)\/reject$/) && options.method === 'POST') {
    const id = endpoint.split('/')[2];
    return mockBackend.rejectContract(id) as unknown as T;
  }

  if (endpoint.match(/^\/contracts\/(.*)\/progress$/) && options.method === 'PUT') {
    const id = endpoint.split('/')[2];
    const body = JSON.parse(options.body as string);
    return mockBackend.updateContractProgress(id, body.progress) as unknown as T;
  }

  if (endpoint === '/chats' && options.method === 'GET') {
    return mockBackend.getChats() as unknown as T;
  }

  // --- FALLBACK (Will likely fail in dev environment) ---
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    let errorMessage = 'An error occurred';
    try {
      const errorData = await response.json();
      errorMessage = errorData.message || errorMessage;
    } catch {
      // Ignore JSON parse errors for error responses
    }
    throw new ApiError(response.status, errorMessage);
  }

  return response.json();
}

export const apiClient = {
  get: <T>(endpoint: string, options?: RequestInit) => request<T>(endpoint, { ...options, method: 'GET' }),
  post: <T>(endpoint: string, data: any, options?: RequestInit) => request<T>(endpoint, { ...options, method: 'POST', body: JSON.stringify(data) }),
  put: <T>(endpoint: string, data: any, options?: RequestInit) => request<T>(endpoint, { ...options, method: 'PUT', body: JSON.stringify(data) }),
  delete: <T>(endpoint: string, options?: RequestInit) => request<T>(endpoint, { ...options, method: 'DELETE' }),
};
