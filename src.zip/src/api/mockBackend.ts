import { Contract, ChatThread, User } from './services';

const INITIAL_CHATS: ChatThread[] = [
  {
    id: 'chat_1',
    name: 'Fresh Foods Co.',
    avatar: 'https://ui-avatars.com/api/?name=Fresh+Foods&background=0D8ABC&color=fff',
    lastMessage: 'Is the price negotiable?',
    time: '10:30 AM',
    unread: 2,
  },
  {
    id: 'chat_2',
    name: 'Green Valley Dairy',
    avatar: 'https://ui-avatars.com/api/?name=Green+Valley&background=2D6A4F&color=fff',
    lastMessage: 'We will dispatch the truck tomorrow morning.',
    time: 'Yesterday',
    unread: 0,
  }
];

const INITIAL_CONTRACTS: Contract[] = [
  {
    id: 'c1',
    buyerName: 'Fresh Foods Co.',
    buyerRating: 4.8,
    category: 'agriculture',
    product: 'Organic Tomatoes',
    productImage: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&q=80&w=800',
    quantity: '500 kg',
    quality: 'Grade A',
    price: '$2.50/kg',
    totalPrice: '$1,250',
    timeline: 'Oct 15 - Nov 30',
    deliveryLocation: 'Central Market, NY',
    distance: '45 miles',
    transportIncluded: false,
    status: 'pending',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'c2',
    buyerName: 'Green Valley Dairy',
    buyerRating: 4.9,
    category: 'dairy',
    product: 'Raw Milk',
    productImage: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&q=80&w=800',
    quantity: '1000 L/week',
    quality: 'Premium',
    price: '$1.20/L',
    totalPrice: '$4,800/mo',
    timeline: 'Ongoing',
    deliveryLocation: 'Processing Plant, NJ',
    distance: '12 miles',
    transportIncluded: true,
    status: 'active',
    progress: 'growing',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'c3',
    buyerName: 'Ocean Catch Inc.',
    buyerRating: 4.6,
    category: 'aquaculture',
    product: 'Atlantic Salmon',
    productImage: 'https://images.unsplash.com/photo-1574781330855-d0db8cc6a79c?auto=format&fit=crop&q=80&w=800',
    quantity: '2000 lbs',
    quality: 'Export Grade',
    price: '$8.50/lb',
    totalPrice: '$17,000',
    timeline: 'Dec 1 - Dec 15',
    deliveryLocation: 'Port Authority, Boston',
    distance: '85 miles',
    transportIncluded: false,
    status: 'pending',
    createdAt: new Date().toISOString(),
  }
];

export const mockBackend = {
  init() {
    if (!localStorage.getItem('mock_contracts')) {
      localStorage.setItem('mock_contracts', JSON.stringify(INITIAL_CONTRACTS));
    }
    const existingChats = localStorage.getItem('mock_chats');
    if (!existingChats || existingChats === '[]') {
      localStorage.setItem('mock_chats', JSON.stringify(INITIAL_CHATS));
    }
  },

  getContracts(status?: string): Contract[] {
    this.init();
    const all = JSON.parse(localStorage.getItem('mock_contracts') || '[]');
    if (status === 'marketplace') {
      return all.filter((c: Contract) => c.status === 'pending');
    }
    if (status) {
      return all.filter((c: Contract) => c.status === status);
    }
    return all;
  },

  getContract(id: string): Contract | undefined {
    this.init();
    const all = JSON.parse(localStorage.getItem('mock_contracts') || '[]');
    return all.find((c: Contract) => c.id === id);
  },

  acceptContract(id: string): Contract {
    this.init();
    const all = JSON.parse(localStorage.getItem('mock_contracts') || '[]');
    const index = all.findIndex((c: Contract) => c.id === id);
    if (index === -1) throw new Error('Contract not found');
    
    all[index].status = 'active';
    all[index].progress = 'planting';
    
    localStorage.setItem('mock_contracts', JSON.stringify(all));
    return all[index];
  },

  rejectContract(id: string): Contract {
    this.init();
    const all = JSON.parse(localStorage.getItem('mock_contracts') || '[]');
    const index = all.findIndex((c: Contract) => c.id === id);
    if (index === -1) throw new Error('Contract not found');
    
    all[index].status = 'rejected';
    
    localStorage.setItem('mock_contracts', JSON.stringify(all));
    return all[index];
  },

  updateContractProgress(id: string, progress: string): Contract {
    this.init();
    const all = JSON.parse(localStorage.getItem('mock_contracts') || '[]');
    const index = all.findIndex((c: Contract) => c.id === id);
    if (index === -1) throw new Error('Contract not found');
    
    all[index].progress = progress;
    if (progress === 'delivered') {
      all[index].status = 'completed';
    }
    
    localStorage.setItem('mock_contracts', JSON.stringify(all));
    return all[index];
  },

  createContract(contractData: any): Contract {
    this.init();
    const all = JSON.parse(localStorage.getItem('mock_contracts') || '[]');
    const newContract: Contract = {
      ...contractData,
      id: `c_${Date.now()}`,
      status: 'pending', // Buyer requirements always start as pending in marketplace
      createdAt: new Date().toISOString(),
      productImage: contractData.productImage || 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&q=80&w=800',
      buyerRating: 5.0,
      buyerName: 'Current User', // Simplified for mock
    };
    all.push(newContract);
    localStorage.setItem('mock_contracts', JSON.stringify(all));
    return newContract;
  },

  getChats(): ChatThread[] {
    this.init();
    return JSON.parse(localStorage.getItem('mock_chats') || '[]');
  }
};
