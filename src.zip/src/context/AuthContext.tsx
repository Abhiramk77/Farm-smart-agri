import React, { useState, createContext, useContext, useEffect } from 'react';
import { authService, User } from '../api/services';

type UserRole = 'buyer' | 'farmer' | 'admin' | null;
type FarmerCategory = 'agriculture' | 'aquaculture' | 'dairy' | 'poultry' | null;

interface AuthContextType {
  user: User | null;
  login: (role: UserRole, category?: FarmerCategory, details?: any) => Promise<void>;
  logout: () => void;
  setPendingRole: (role: UserRole, category?: FarmerCategory) => void;
  pendingRole: {
    role: UserRole;
    category?: FarmerCategory;
  } | null;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: {children: React.ReactNode;}) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [pendingRole, setPendingRoleState] = useState<{
    role: UserRole;
    category?: FarmerCategory;
  } | null>(null);

  useEffect(() => {
    // Attempt to load user profile if token exists
    const token = localStorage.getItem('auth_token');
    if (token) {
      authService.getProfile()
        .then(userData => setUser(userData))
        .catch(() => {
          localStorage.removeItem('auth_token');
          setUser(null);
        })
        .finally(() => setIsLoading(false));
    } else {
      setIsLoading(false);
    }
  }, []);

  const login = async (role: UserRole, category?: FarmerCategory, details?: any) => {
    if (!role) return;
    try {
      // In a real scenario, this would send credentials. 
      // For now, we simulate API login based on role.
      const data = await authService.login(role, category || undefined);
      localStorage.setItem('auth_token', data.token);
      setUser({ ...data.user, ...details });
    } catch (error) {
      console.error("Login failed via API, falling back to local user for development.");
      // Fallback for development if no backend exists yet
      setUser({
        id: 'u1',
        name: details?.name || (role === 'buyer' ? 'Acme Corp Buyer' : 'John Doe'),
        role,
        category,
        ...details
      });
    }
  };

  const logout = () => {
    localStorage.removeItem('auth_token');
    setUser(null);
  };

  const setPendingRole = (role: UserRole, category?: FarmerCategory) => {
    setPendingRoleState({
      role,
      category
    });
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        logout,
        pendingRole,
        setPendingRole,
        isLoading
      }}>
      
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}